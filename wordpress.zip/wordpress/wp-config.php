<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', '127.0.0.1');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'c2AI:8!v/mP?0imNqN,}?#1;Sfz3E(;Tp+,(:70L 78BT+ozMU,&lnpP_c<.@NOQ');
define('SECURE_AUTH_KEY',  'P^,_F!Ojn!xi[~b0yf.ApqBF8l>gI3~E}jFKE:Q%]XdmsifhAmc ,v;gdG*+TUl(');
define('LOGGED_IN_KEY',    'c[7$eqX;-Fc4L$G&s}FC5c8(m(GP*Be=nGGH;5%@uk=`c.[$(*4G4BQ,d2#^?TNE');
define('NONCE_KEY',        'snbPxe[5-al+5.T9/tP92Vk#fyrt$.2`2Vod8ECL=dNNUl}4}yc`Az,Io/$<dp3p');
define('AUTH_SALT',        'y>.B,kXqcz[TBOR.d7y5:+xQ:zR;u1uLzjw1Q7mAZ3`jb_fe1OuUzZf&Ejk^7{8,');
define('SECURE_AUTH_SALT', 'I2}^aHEHPV(cwqdP!2+Pq+{$pxn@bm~m1Cd$Be5Eb+IOQ3GU]T[35IlWGrXw?nuA');
define('LOGGED_IN_SALT',   'TNhD~B#RF)$3Lr<)e)G&k|X4U2)+h,P2Ze.]ojI#FR#n1O;t@gbz 7%EHxx,Z{Q,');
define('NONCE_SALT',       'a)GojZWd[nET(_JJ|lQGpZkr7&v3fb@,h8zh?n<E!lWCksL*#V(_Z!/5%k.zxby=');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
